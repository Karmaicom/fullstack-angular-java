package br.com.coti.api_clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
